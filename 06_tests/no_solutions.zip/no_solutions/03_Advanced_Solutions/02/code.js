// Task: Given an array of objects with properties like name, age, and country, write a JavaScript program that sorts the array based on age in descending order. 
// Then, filter the array to extract and display the names of people aged 30 or older.
