//Advanced DOM Manipulation and API Integration

// Task: Build a web page that allows users to search for movies by title using the OMDB API. 
// Implement a search input and a "Search" button. 
// When the user enters a title and clicks "Search," display a list of matching movie titles with posters and details.
