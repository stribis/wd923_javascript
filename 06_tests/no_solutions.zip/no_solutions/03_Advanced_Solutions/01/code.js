// Task: Create a program that generates a random list of 10 integers within a specific range (e.g., 1 to 100) and stores them in an array. 
// Find and display the sum, average, and product of the elements. 
// Additionally, implement a way to identify and display the largest and smallest numbers in the array.

