// Task: Create a JavaScript function that takes an array of numbers and returns the median value.
// The function should handle both odd and even-length arrays. 
// Test the function with various arrays to ensure it works correctly.

