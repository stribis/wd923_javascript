// Complex Conditional Logic

// Task: Create a program that simulates a simple game. Ask the user to guess a random number between 1 and 100. 
// Provide hints like "too high" or "too low" until the user guesses the correct number. Keep track of the number of attempts, and display it once they guess correctly.

