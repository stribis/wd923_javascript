// Task: Given an array of numbers, write a program that finds and displays the sum of all even numbers and the product of all odd numbers in the array.
