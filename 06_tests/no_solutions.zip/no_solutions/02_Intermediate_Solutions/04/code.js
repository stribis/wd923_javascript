// Task: Create a program that prompts the user to enter a number. 
// Check if the number is positive, negative, or zero, and display an appropriate message.
