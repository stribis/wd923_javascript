// Task: Build a webpage with a button. 
// When the button is clicked, change the background color of the webpage to a random color. 
// Add a text element that displays the new background color.
