// Task: Create a JavaScript program that calculates the area and perimeter of a rectangle. 
// Ask the user to enter the length and width as input, and then display both the area and perimeter.