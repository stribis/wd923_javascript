// Task: Write a JavaScript function that takes a user's name as input and returns a greeting message using the name. 
// For example, if the user inputs "Alice," the function should return "Hello, Alice!".
