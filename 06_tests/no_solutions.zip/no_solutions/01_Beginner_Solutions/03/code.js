// Task: Write a JavaScript function named calculateArea that takes two parameters, length and width, and returns the area of a rectangle. 
// Call this function with different sets of length and width values to calculate and display the areas.
