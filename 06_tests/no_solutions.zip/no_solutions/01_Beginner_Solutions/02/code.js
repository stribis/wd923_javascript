// Task: Create an array of numbers. Write a loop to find and display the largest number in the array. 
// Additionally, write another loop to calculate the sum of all the numbers in the array.
