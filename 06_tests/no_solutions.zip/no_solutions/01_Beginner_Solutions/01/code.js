
// Task: Declare two variables, num1 and num2, and assign them numeric values. 
// Calculate the sum, difference, product, and quotient of these two numbers. 
// Display the results on the console.
